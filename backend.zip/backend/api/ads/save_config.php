<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config/repository.php';
require_once __DIR__ . '/../../config/auth.php';

api_bootstrap();
require_method('POST');
require_admin_api();
verify_csrf();

const MAX_ADX_IDS_PER_TYPE = 20;
const MAX_SEQUENCE_ITEMS = 50;
const MAX_SCREENS = 100;

$body = read_json_body();
$errors = [];

// Ad units (AdMob + TradPlus)
$units = [];
foreach (['admob' => ADMOB_TYPES, 'tradplus' => TRADPLUS_TYPES] as $provider => $types) {
    foreach ($types as $type) {
        $item = $body[$provider][$type] ?? [];
        $id = clean_string(is_array($item) ? ($item['id'] ?? '') : '', 191);
        $enabled = to_bool(is_array($item) ? ($item['enabled'] ?? false) : false);
        if (!is_valid_ad_unit_id($id)) {
            $errors["$provider.$type.id"] = 'Ad unit ID cannot contain spaces';
        } elseif ($enabled && $id === '') {
            $errors["$provider.$type.id"] = 'Enter an ad unit ID or turn this off';
        }
        $units[] = [$provider, $type, $id, $enabled];
    }
}

// Custom ads
$customEnabled = to_bool($body['custom']['enabled'] ?? false);
$customUrl = clean_string($body['custom']['url'] ?? '', 500);
if ($customUrl !== '' && !is_valid_url($customUrl)) {
    $errors['custom.url'] = 'Enter a valid URL (https://...)';
} elseif ($customEnabled && $customUrl === '') {
    $errors['custom.url'] = 'Custom Ads URL is required when enabled';
}

// ADX weighted IDs
$adxRows = [];
foreach (ADX_TYPES as $type) {
    $list = $body['adx'][$type] ?? [];
    if (!is_array($list)) {
        $list = [];
    }
    if (count($list) > MAX_ADX_IDS_PER_TYPE) {
        $errors["adx.$type"] = 'Maximum ' . MAX_ADX_IDS_PER_TYPE . ' IDs per ad type';
        continue;
    }
    foreach (array_values($list) as $index => $row) {
        $id = clean_string(is_array($row) ? ($row['id'] ?? '') : '', 191);
        $weightRaw = is_array($row) ? ($row['weight'] ?? '') : '';
        if ($id === '' || !is_valid_ad_unit_id($id)) {
            $errors["adx.$type.$index.id"] = $id === '' ? 'Enter an ad unit ID or remove the row' : 'Ad unit ID cannot contain spaces';
        }
        if (!is_numeric($weightRaw) || (int) $weightRaw != $weightRaw) {
            $errors["adx.$type.$index.weight"] = 'Weight must be a whole number';
        } elseif ((int) $weightRaw < 0) {
            $errors["adx.$type.$index.weight"] = 'Weight cannot be negative';
        } elseif ((int) $weightRaw > 1000000) {
            $errors["adx.$type.$index.weight"] = 'Weight is too large';
        }
        $adxRows[] = [$type, $id, max(0, (int) $weightRaw), $index];
    }
}

// Fullscreen sequence
$sequence = $body['fullscreen_sequence'] ?? [];
if (!is_array($sequence)) {
    $sequence = [];
}
$sequence = array_values($sequence);
if (count($sequence) > MAX_SEQUENCE_ITEMS) {
    $errors['fullscreen_sequence'] = 'Maximum ' . MAX_SEQUENCE_ITEMS . ' sequence items';
}
foreach ($sequence as $type) {
    if (!in_array($type, FULLSCREEN_TYPES, true)) {
        $errors['fullscreen_sequence'] = 'Unknown fullscreen ad type';
        break;
    }
}

// Per-screen ad switches
$screens = $body['screen_ads'] ?? [];
if (!is_array($screens)) {
    $screens = [];
}
if (count($screens) > MAX_SCREENS) {
    $errors['screen_ads'] = 'Too many screens';
    $screens = [];
}
$screenRows = [];
$seenKeys = [];
foreach (array_values($screens) as $index => $screen) {
    $key = strtolower(clean_string(is_array($screen) ? ($screen['screen_key'] ?? '') : '', 50));
    if (!preg_match(SCREEN_KEY_PATTERN, $key)) {
        $errors["screen_ads.$index.screen_key"] = 'Use lowercase letters, numbers and underscores (e.g. settings_screen)';
        continue;
    }
    if (isset($seenKeys[$key])) {
        $errors["screen_ads.$index.screen_key"] = 'Duplicate screen key';
        continue;
    }
    $seenKeys[$key] = true;
    $label = clean_string($screen['label'] ?? '', 100);
    $screenRows[] = [
        $key,
        $label !== '' ? $label : $key,
        to_bool($screen['native_big'] ?? false),
        to_bool($screen['native_small'] ?? false),
        to_bool($screen['banner'] ?? false),
        to_bool($screen['fullscreen'] ?? false),
        $index + 1,
    ];
}
foreach (DEFAULT_SCREENS as $defaultKey) {
    if (!isset($seenKeys[$defaultKey]) && !isset($errors['screen_ads'])) {
        $errors['screen_ads'] = "Default screen '$defaultKey' cannot be removed";
        break;
    }
}

if ($errors) {
    validation_error($errors);
}

$pdo = db();
$pdo->beginTransaction();

$unitStmt = $pdo->prepare(
    'INSERT INTO ad_units (provider, ad_type, ad_unit_id, enabled) VALUES (:p, :t, :id, :en)
     ON DUPLICATE KEY UPDATE ad_unit_id = VALUES(ad_unit_id), enabled = VALUES(enabled)'
);
foreach ($units as [$provider, $type, $id, $enabled]) {
    $unitStmt->execute([':p' => $provider, ':t' => $type, ':id' => $id, ':en' => (int) $enabled]);
}

$pdo->prepare('UPDATE app_settings SET custom_ads_enabled = :en, custom_ads_url = :url WHERE id = 1')
    ->execute([':en' => (int) $customEnabled, ':url' => $customUrl]);

$pdo->exec('DELETE FROM adx_weighted_ids');
$adxStmt = $pdo->prepare('INSERT INTO adx_weighted_ids (ad_type, ad_unit_id, weight, enabled, sort_order) VALUES (:t, :id, :w, 1, :o)');
foreach ($adxRows as [$type, $id, $weight, $order]) {
    $adxStmt->execute([':t' => $type, ':id' => $id, ':w' => $weight, ':o' => $order]);
}

$pdo->exec('DELETE FROM fullscreen_sequence');
$seqStmt = $pdo->prepare('INSERT INTO fullscreen_sequence (ad_type, sort_order, enabled) VALUES (:t, :o, 1)');
foreach ($sequence as $index => $type) {
    $seqStmt->execute([':t' => $type, ':o' => $index + 1]);
}

$screenStmt = $pdo->prepare(
    'INSERT INTO screen_ad_config (screen_key, label, native_big_enabled, native_small_enabled, banner_enabled, fullscreen_enabled, sort_order)
     VALUES (:k, :l, :nb, :ns, :b, :f, :o)
     ON DUPLICATE KEY UPDATE label = VALUES(label), native_big_enabled = VALUES(native_big_enabled),
        native_small_enabled = VALUES(native_small_enabled), banner_enabled = VALUES(banner_enabled),
        fullscreen_enabled = VALUES(fullscreen_enabled), sort_order = VALUES(sort_order)'
);
foreach ($screenRows as [$key, $label, $nb, $ns, $b, $f, $order]) {
    $screenStmt->execute([
        ':k' => $key, ':l' => $label, ':nb' => (int) $nb, ':ns' => (int) $ns,
        ':b' => (int) $b, ':f' => (int) $f, ':o' => $order,
    ]);
}
$keys = array_keys($seenKeys);
$placeholders = implode(',', array_fill(0, count($keys), '?'));
$pdo->prepare("DELETE FROM screen_ad_config WHERE screen_key NOT IN ($placeholders)")->execute($keys);

bump_config_version();
$pdo->commit();

json_response(true, 'Ads configuration saved', get_ads_config());
