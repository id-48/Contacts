<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth_check.php';

$pageTitle = 'Ads Configuration';
$pageKey = 'ads';
require __DIR__ . '/includes/header.php';
?>
<form id="adsForm" class="stack" novalidate>
    <div class="loading-overlay" data-loading-overlay><span class="spinner"></span></div>

    <section class="grid-2">
        <div class="card">
            <div class="card-head">
                <h2>AdMob</h2>
                <p class="muted">Turn on a format and enter its ad unit ID.</p>
            </div>
            <div data-units="admob"></div>
        </div>
        <div class="card">
            <div class="card-head">
                <h2>TradPlus</h2>
                <p class="muted">Turn on a format and enter its TradPlus unit ID.</p>
            </div>
            <div data-units="tradplus"></div>
        </div>
    </section>

    <section class="card">
        <div class="card-head">
            <h2>Custom Ads</h2>
            <p class="muted">The app uses this URL only when Custom Ads is enabled.</p>
        </div>
        <div class="toggle-row">
            <div><p class="toggle-title">Enabled</p></div>
            <label class="switch">
                <input type="checkbox" data-key="custom.enabled">
                <span class="slider"></span>
            </label>
        </div>
        <div class="field">
            <label for="customUrl">Custom Ads URL</label>
            <input id="customUrl" type="url" data-key="custom.url" placeholder="https://example.com/custom-ads.json">
        </div>
    </section>

    <section class="card">
        <div class="card-head">
            <h2>ADX Weighted IDs</h2>
            <p class="muted">Each request picks one ID at random, in proportion to its weight. Weights do not need to add up to 100.</p>
        </div>
        <div class="adx-grid" id="adxGroups"></div>
    </section>

    <section class="card">
        <div class="card-head">
            <h2>Fullscreen sequence</h2>
            <p class="muted">Click a type to append it. Click a chip in the sequence to remove it. The app shows them in this order and loops.</p>
        </div>
        <div class="chip-palette" id="sequencePalette"></div>
        <div class="sequence" id="sequenceList"></div>
        <p class="field-error" data-error-for="fullscreen_sequence"></p>
        <button class="btn btn-ghost btn-sm" type="button" id="sequenceReset">Reset to default</button>
    </section>

    <section class="card">
        <div class="card-head">
            <h2>Per-screen ads</h2>
            <p class="muted">Choose which ad formats appear on each screen.</p>
        </div>
        <div class="table-wrap">
            <table class="table screen-table">
                <thead>
                <tr>
                    <th>Screen</th>
                    <th>Native Big</th>
                    <th>Native Small</th>
                    <th>Banner</th>
                    <th>Fullscreen</th>
                    <th></th>
                </tr>
                </thead>
                <tbody id="screenRows"></tbody>
            </table>
        </div>
        <p class="field-error" data-error-for="screen_ads"></p>
        <div class="add-screen">
            <div class="field">
                <label for="newScreenKey">Screen key</label>
                <input id="newScreenKey" type="text" placeholder="settings_screen" maxlength="50">
            </div>
            <div class="field">
                <label for="newScreenLabel">Label</label>
                <input id="newScreenLabel" type="text" placeholder="Settings" maxlength="100">
            </div>
            <button class="btn btn-ghost" type="button" id="addScreen">Add screen</button>
        </div>
    </section>

    <div class="save-bar">
        <button class="btn btn-primary" type="submit">Save ads configuration</button>
    </div>
</form>
<?php require __DIR__ . '/includes/footer.php'; ?>
