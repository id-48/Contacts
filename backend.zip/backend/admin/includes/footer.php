<?php declare(strict_types=1); ?>
        </main>
    </div>
</div>
<div class="toast-stack" id="toastStack" aria-live="polite"></div>
<script src="../assets/js/admin.js"></script>
</body>
</html>
