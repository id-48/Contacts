(function () {
    'use strict';

    const API = '../api/';
    const VERSION_RE = /^\d+(\.\d+){0,3}$/;
    const SCREEN_KEY_RE = /^[a-z][a-z0-9_]{1,49}$/;
    const NO_SPACE_RE = /^\S*$/;
    const FULLSCREEN_TYPES = [
        ['interstitial', 'Interstitial'],
        ['reward', 'Reward'],
        ['app_open', 'App Open'],
        ['custom', 'Custom'],
    ];
    const DEFAULT_SEQUENCE = ['interstitial', 'reward', 'app_open', 'custom'];
    const ADX_TYPES = ['banner', 'interstitial', 'native', 'app_open', 'reward'];
    const AD_TYPE_LABELS = {
        banner: 'Banner',
        interstitial: 'Interstitial',
        native: 'Native',
        reward: 'Reward',
        app_open: 'App Open',
    };

    // ---------- Helpers ----------

    class ApiError extends Error {
        constructor(message, data, status) {
            super(message);
            this.data = data;
            this.status = status;
        }
    }

    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

    function esc(value) {
        return String(value ?? '').replace(/[&<>"']/g, (c) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
        })[c]);
    }

    function csrfToken() {
        const meta = $('meta[name="csrf-token"]');
        return meta ? meta.content : '';
    }

    async function api(path, { method = 'GET', body } = {}) {
        const options = { method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
        if (body !== undefined) {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(body);
        }
        if (method !== 'GET') {
            options.headers['X-CSRF-Token'] = csrfToken();
        }

        let response;
        try {
            response = await fetch(API + path, options);
        } catch (e) {
            throw new ApiError('Network error. Check your connection and try again.', null, 0);
        }

        let json = null;
        try {
            json = await response.json();
        } catch (e) {
            json = null;
        }

        if (response.status === 401 && document.body.dataset.page !== 'login') {
            window.location.href = 'login.php';
            throw new ApiError('Session expired', null, 401);
        }
        if (!response.ok || !json || !json.success) {
            throw new ApiError((json && json.message) || `Request failed (${response.status})`, json && json.data, response.status);
        }
        return json;
    }

    function toast(message, type = 'success') {
        const stack = $('#toastStack');
        if (!stack) return;
        const el = document.createElement('div');
        el.className = `toast${type === 'error' ? ' toast-error' : ''}`;
        el.setAttribute('role', type === 'error' ? 'alert' : 'status');
        el.textContent = message;
        stack.appendChild(el);
        setTimeout(() => {
            el.classList.add('hide');
            setTimeout(() => el.remove(), 250);
        }, type === 'error' ? 5000 : 3000);
    }

    function setButtonLoading(button, loading) {
        if (!button) return;
        if (loading) {
            button.dataset.label = button.textContent;
            button.disabled = true;
            button.innerHTML = `<span class="spinner"></span>${esc(button.dataset.label.trim())}`;
        } else {
            button.disabled = false;
            button.textContent = button.dataset.label || button.textContent;
        }
    }

    function setSectionLoading(form, loading) {
        form.classList.toggle('is-loading', loading);
    }

    function clearErrors(root) {
        $$('.is-invalid', root).forEach((el) => el.classList.remove('is-invalid'));
        $$('.field-error[data-generated]', root).forEach((el) => el.remove());
        $$('[data-error-for]', root).forEach((el) => { el.textContent = ''; });
    }

    function showErrors(root, errors) {
        const unmatched = [];
        let first = null;
        Object.entries(errors || {}).forEach(([key, message]) => {
            const input = $(`[data-key="${CSS.escape(key)}"]`, root);
            const slot = $(`[data-error-for="${CSS.escape(key)}"]`, root);
            if (input) {
                input.classList.add('is-invalid');
                const p = document.createElement('p');
                p.className = 'field-error';
                p.dataset.generated = '1';
                p.textContent = message;
                (input.closest('.input-group') || input).insertAdjacentElement('afterend', p);
                first = first || input;
            } else if (slot) {
                slot.textContent = message;
                first = first || slot;
            } else {
                unmatched.push(message);
            }
        });
        if (unmatched.length) toast(unmatched.join(' '), 'error');
        if (first) first.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function readForm(form) {
        const data = {};
        $$('[data-key]', form).forEach((el) => {
            data[el.dataset.key] = el.type === 'checkbox' ? el.checked : el.value.trim();
        });
        return data;
    }

    function fillForm(form, data) {
        $$('[data-key]', form).forEach((el) => {
            if (!(el.dataset.key in data)) return;
            const value = data[el.dataset.key];
            if (el.type === 'checkbox') el.checked = Boolean(value);
            else el.value = value ?? '';
        });
    }

    function isValidUrl(value) {
        try {
            const url = new URL(value);
            return ['http:', 'https:', 'market:'].includes(url.protocol);
        } catch (e) {
            return false;
        }
    }

    /** Disable -> loading -> validate -> save -> toast -> reload -> enable. */
    function bindSubmit(form, { validate, save }) {
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            const button = $('[type="submit"]', form);
            if (button.disabled) return;
            clearErrors(form);
            setButtonLoading(button, true);
            try {
                const errors = validate ? validate() : {};
                if (Object.keys(errors).length) {
                    showErrors(form, errors);
                    return;
                }
                await save();
            } catch (err) {
                if (err.data && err.data.errors) showErrors(form, err.data.errors);
                toast(err.message, 'error');
            } finally {
                setButtonLoading(button, false);
            }
        });

        form.addEventListener('input', (event) => {
            const el = event.target;
            if (!el.classList.contains('is-invalid')) return;
            el.classList.remove('is-invalid');
            const anchor = el.closest('.input-group') || el;
            const next = anchor.nextElementSibling;
            if (next && next.dataset.generated) next.remove();
        });
    }

    function formatNumber(n) {
        return Number(n || 0).toLocaleString();
    }

    function formatDate(value) {
        if (!value) return '–';
        const date = new Date(value.replace(' ', 'T') + 'Z');
        return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
    }

    // ---------- Global UI ----------

    function initChrome() {
        $$('[data-sidebar-open]').forEach((btn) => btn.addEventListener('click', () => document.body.classList.add('sidebar-open')));
        $$('[data-sidebar-close]').forEach((el) => el.addEventListener('click', () => document.body.classList.remove('sidebar-open')));
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') document.body.classList.remove('sidebar-open');
        });
        $$('[data-toggle-password]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const input = document.getElementById(btn.dataset.togglePassword);
                const show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                btn.textContent = show ? 'Hide' : 'Show';
            });
        });
    }

    // ---------- Pages ----------

    const pages = {};

    pages.login = function () {
        const form = $('#loginForm');
        bindSubmit(form, {
            validate() {
                const data = readForm(form);
                const errors = {};
                if (!/^\S+@\S+\.\S+$/.test(data.email)) errors.email = 'Enter a valid email address';
                if (!data.password) errors.password = 'Enter your password';
                return errors;
            },
            async save() {
                const data = readForm(form);
                const json = await api('auth/login.php', { method: 'POST', body: { email: data.email, password: data.password } });
                window.location.href = json.data.redirect;
            },
        });
    };

    pages.dashboard = async function () {
        try {
            const { data } = await api('dashboard/stats.php');
            $$('[data-stat]').forEach((el) => {
                const key = el.dataset.stat;
                el.textContent = key.endsWith('_percent') ? `${data[key]}%` : formatNumber(data[key]);
            });
            const bar = $('#breakdownBar');
            const hasUsers = data.total > 0;
            bar.children[0].style.width = `${hasUsers ? data.organic_percent : 0}%`;
            bar.children[1].style.width = `${hasUsers ? data.marketing_percent : 0}%`;
            renderWeekChart(data.last_7_days);
        } catch (err) {
            toast(err.message, 'error');
            $$('[data-stat]').forEach((el) => { el.textContent = '–'; });
        }
    };

    function renderWeekChart(days) {
        const chart = $('#weekChart');
        const max = Math.max(1, ...days.map((d) => d.organic + d.marketing));
        chart.innerHTML = days.map((d) => {
            const label = new Date(d.date + 'T00:00:00').toLocaleDateString(undefined, { weekday: 'short' });
            const organic = (d.organic / max) * 100;
            const marketing = (d.marketing / max) * 100;
            const title = `${d.date}: ${d.organic} organic, ${d.marketing} marketing`;
            return `<div class="bar-col" title="${esc(title)}">
                <div class="bar-stack">
                    <span class="seg-organic" style="height:${organic}%"></span>
                    <span class="seg-marketing" style="height:${marketing}%"></span>
                </div>
                <span class="bar-label">${esc(label)}</span>
            </div>`;
        }).join('');
    }

    pages.settings = function () {
        const form = $('#settingsForm');

        async function load() {
            setSectionLoading(form, true);
            try {
                const { data } = await api('app/get_settings.php');
                fillForm(form, data);
            } catch (err) {
                toast(err.message, 'error');
            } finally {
                setSectionLoading(form, false);
            }
        }

        bindSubmit(form, {
            validate() {
                const d = readForm(form);
                const errors = {};
                ['privacy_policy_url', 'app_link'].forEach((key) => {
                    if (d[key] && !isValidUrl(d[key])) errors[key] = 'Enter a valid URL (https://...)';
                });
                if (d.app_version && !VERSION_RE.test(d.app_version)) errors.app_version = 'Use a version like 1.0.0';
                if (d.minimum_version && !VERSION_RE.test(d.minimum_version)) errors.minimum_version = 'Use a version like 1.0.0';
                if (d.force_update) {
                    if (!d.app_version) errors.app_version = 'App version is required when force update is enabled';
                    if (!d.minimum_version) errors.minimum_version = 'Minimum version is required when force update is enabled';
                    if (!d.force_update_message) errors.force_update_message = 'Update message is required when force update is enabled';
                    if (!d.app_link) errors.app_link = 'App link is required when force update is enabled';
                }
                return errors;
            },
            async save() {
                const json = await api('app/save_settings.php', { method: 'POST', body: readForm(form) });
                fillForm(form, json.data);
                toast('Settings saved');
            },
        });

        load();
    };

    pages.ads = function () {
        const form = $('#adsForm');
        const state = { sequence: [] };

        // Ad units
        function renderUnits(provider, units) {
            const container = $(`[data-units="${provider}"]`, form);
            const placeholder = provider === 'admob' ? 'ca-app-pub-xxxxxxxx/xxxxxxxx' : 'TradPlus unit ID';
            container.innerHTML = Object.keys(units).map((type) => `
                <div class="unit-row">
                    <span class="unit-label">${esc(AD_TYPE_LABELS[type] || type)}</span>
                    <label class="switch" aria-label="${esc(AD_TYPE_LABELS[type])} enabled">
                        <input type="checkbox" data-key="${provider}.${type}.enabled">
                        <span class="slider"></span>
                    </label>
                    <input type="text" data-key="${provider}.${type}.id" placeholder="${esc(placeholder)}" maxlength="191" spellcheck="false">
                </div>`).join('');
            Object.entries(units).forEach(([type, unit]) => {
                $(`[data-key="${provider}.${type}.enabled"]`, container).checked = Boolean(unit.enabled);
                $(`[data-key="${provider}.${type}.id"]`, container).value = unit.id || '';
            });
        }

        // ADX weighted IDs
        function renderAdx(adx) {
            const container = $('#adxGroups');
            container.innerHTML = ADX_TYPES.map((type) => `
                <div class="adx-group" data-adx-type="${type}">
                    <div class="adx-group-head">
                        <h3>ADX ${esc(type)}</h3>
                        <span class="muted" data-adx-total></span>
                    </div>
                    <div data-adx-rows></div>
                    <p class="field-error" data-error-for="adx.${type}"></p>
                    <button class="btn btn-ghost btn-sm" type="button" data-adx-add>+ Add ID</button>
                </div>`).join('');
            ADX_TYPES.forEach((type) => {
                const group = $(`[data-adx-type="${type}"]`, container);
                (adx[type] || []).forEach((row) => addAdxRow(group, row.id, row.weight));
                refreshAdxGroup(group);
            });
        }

        function addAdxRow(group, id = '', weight = 50) {
            const row = document.createElement('div');
            row.className = 'adx-row';
            row.innerHTML = `
                <input type="text" data-field="id" placeholder="/1234567/ad_unit" maxlength="191" spellcheck="false">
                <input type="number" data-field="weight" min="0" step="1" placeholder="Weight">
                <button class="btn btn-danger-ghost btn-sm" type="button" data-adx-remove>Remove</button>
                <span class="share"></span>`;
            $('[data-field="id"]', row).value = id;
            $('[data-field="weight"]', row).value = weight;
            $('[data-adx-rows]', group).appendChild(row);
        }

        function refreshAdxGroup(group) {
            const type = group.dataset.adxType;
            const rows = $$('.adx-row', group);
            const weights = rows.map((row) => Math.max(0, parseInt($('[data-field="weight"]', row).value, 10) || 0));
            const total = weights.reduce((a, b) => a + b, 0);
            rows.forEach((row, index) => {
                $('[data-field="id"]', row).dataset.key = `adx.${type}.${index}.id`;
                $('[data-field="weight"]', row).dataset.key = `adx.${type}.${index}.weight`;
                $('.share', row).textContent = total > 0 ? `≈ ${((weights[index] / total) * 100).toFixed(1)}% of requests` : '';
            });
            const existingEmpty = $('.adx-empty', group);
            if (!rows.length && !existingEmpty) {
                $('[data-adx-rows]', group).insertAdjacentHTML('beforebegin', '<p class="adx-empty">No IDs yet.</p>');
            } else if (rows.length && existingEmpty) {
                existingEmpty.remove();
            }
            $('[data-adx-total]', group).textContent = rows.length ? `Total weight: ${total}` : '';
        }

        $('#adxGroups').addEventListener('click', (event) => {
            const group = event.target.closest('.adx-group');
            if (!group) return;
            if (event.target.closest('[data-adx-add]')) {
                addAdxRow(group, '', 50);
                refreshAdxGroup(group);
                $('.adx-row:last-child [data-field="id"]', group).focus();
            } else if (event.target.closest('[data-adx-remove]')) {
                event.target.closest('.adx-row').remove();
                clearErrors(group);
                refreshAdxGroup(group);
            }
        });
        $('#adxGroups').addEventListener('input', (event) => {
            if (event.target.dataset.field === 'weight') refreshAdxGroup(event.target.closest('.adx-group'));
        });

        // Fullscreen sequence
        function renderPalette() {
            $('#sequencePalette').innerHTML = FULLSCREEN_TYPES.map(([type, label], index) => `
                <button class="chip" type="button" data-sequence-add="${type}">
                    <span class="chip-num">${index + 1}</span>${esc(label)}
                </button>`).join('');
        }

        function renderSequence() {
            const list = $('#sequenceList');
            if (!state.sequence.length) {
                list.innerHTML = '<span class="sequence-empty">No fullscreen ads will be shown. Click a type above to add one.</span>';
                return;
            }
            const labels = Object.fromEntries(FULLSCREEN_TYPES);
            list.innerHTML = state.sequence.map((type, index) => `
                <button class="chip chip-active" type="button" data-sequence-remove="${index}" title="Click to remove">
                    <span class="chip-num">${index + 1}</span>${esc(labels[type] || type)}
                </button>`).join('');
        }

        $('#sequencePalette').addEventListener('click', (event) => {
            const chip = event.target.closest('[data-sequence-add]');
            if (!chip) return;
            if (state.sequence.length >= 50) {
                toast('Maximum 50 sequence items', 'error');
                return;
            }
            state.sequence.push(chip.dataset.sequenceAdd);
            renderSequence();
        });
        $('#sequenceList').addEventListener('click', (event) => {
            const chip = event.target.closest('[data-sequence-remove]');
            if (!chip) return;
            state.sequence.splice(Number(chip.dataset.sequenceRemove), 1);
            renderSequence();
        });
        $('#sequenceReset').addEventListener('click', () => {
            state.sequence = DEFAULT_SEQUENCE.slice();
            renderSequence();
        });

        // Per-screen ads
        const SCREEN_FLAGS = [['native_big', 'Native Big'], ['native_small', 'Native Small'], ['banner', 'Banner'], ['fullscreen', 'Fullscreen']];

        function screenRowHtml(screen) {
            const toggles = SCREEN_FLAGS.map(([flag, label]) => `
                <td data-label="${label}">
                    <label class="switch" aria-label="${esc(screen.label)} ${label}">
                        <input type="checkbox" data-flag="${flag}"${screen[flag] ? ' checked' : ''}>
                        <span class="slider"></span>
                    </label>
                </td>`).join('');
            const remove = screen.is_default
                ? '<td data-label=""></td>'
                : '<td data-label=""><button class="btn btn-danger-ghost btn-sm" type="button" data-screen-remove>Remove</button></td>';
            return `<tr data-screen-key="${esc(screen.screen_key)}" data-screen-label="${esc(screen.label)}">
                <td data-label="Screen"><strong>${esc(screen.label)}</strong><span class="screen-key">${esc(screen.screen_key)}</span></td>
                ${toggles}${remove}
            </tr>`;
        }

        function renderScreens(screens) {
            $('#screenRows').innerHTML = screens.map(screenRowHtml).join('');
        }

        $('#screenRows').addEventListener('click', (event) => {
            if (event.target.closest('[data-screen-remove]')) event.target.closest('tr').remove();
        });

        $('#addScreen').addEventListener('click', () => {
            const keyInput = $('#newScreenKey');
            const labelInput = $('#newScreenLabel');
            const key = keyInput.value.trim().toLowerCase();
            const label = labelInput.value.trim() || key;
            keyInput.classList.remove('is-invalid');
            if (!SCREEN_KEY_RE.test(key)) {
                keyInput.classList.add('is-invalid');
                toast('Screen key: lowercase letters, numbers and underscores (e.g. settings_screen)', 'error');
                return;
            }
            if ($(`#screenRows tr[data-screen-key="${CSS.escape(key)}"]`)) {
                keyInput.classList.add('is-invalid');
                toast('This screen key already exists', 'error');
                return;
            }
            $('#screenRows').insertAdjacentHTML('beforeend', screenRowHtml({ screen_key: key, label, is_default: false }));
            keyInput.value = '';
            labelInput.value = '';
        });

        function render(data) {
            renderUnits('admob', data.admob);
            renderUnits('tradplus', data.tradplus);
            $('[data-key="custom.enabled"]', form).checked = Boolean(data.custom.enabled);
            $('[data-key="custom.url"]', form).value = data.custom.url || '';
            renderAdx(data.adx);
            state.sequence = (data.fullscreen_sequence || []).slice();
            renderSequence();
            renderScreens(data.screen_ads || []);
        }

        function gather() {
            const body = { admob: {}, tradplus: {}, custom: {}, adx: {}, fullscreen_sequence: state.sequence.slice(), screen_ads: [] };
            $$('[data-units] [data-key]', form).forEach((el) => {
                const [provider, type, field] = el.dataset.key.split('.');
                body[provider][type] = body[provider][type] || {};
                body[provider][type][field] = el.type === 'checkbox' ? el.checked : el.value.trim();
            });
            body.custom = {
                enabled: $('[data-key="custom.enabled"]', form).checked,
                url: $('[data-key="custom.url"]', form).value.trim(),
            };
            $$('.adx-group', form).forEach((group) => {
                body.adx[group.dataset.adxType] = $$('.adx-row', group).map((row) => ({
                    id: $('[data-field="id"]', row).value.trim(),
                    weight: $('[data-field="weight"]', row).value.trim(),
                }));
            });
            $$('#screenRows tr', form).forEach((tr) => {
                const screen = { screen_key: tr.dataset.screenKey, label: tr.dataset.screenLabel };
                $$('[data-flag]', tr).forEach((input) => { screen[input.dataset.flag] = input.checked; });
                body.screen_ads.push(screen);
            });
            return body;
        }

        function validate() {
            const body = gather();
            const errors = {};
            ['admob', 'tradplus'].forEach((provider) => {
                Object.entries(body[provider]).forEach(([type, unit]) => {
                    if (!NO_SPACE_RE.test(unit.id)) errors[`${provider}.${type}.id`] = 'Ad unit ID cannot contain spaces';
                    else if (unit.enabled && !unit.id) errors[`${provider}.${type}.id`] = 'Enter an ad unit ID or turn this off';
                });
            });
            if (body.custom.url && !isValidUrl(body.custom.url)) errors['custom.url'] = 'Enter a valid URL (https://...)';
            else if (body.custom.enabled && !body.custom.url) errors['custom.url'] = 'Custom Ads URL is required when enabled';
            Object.entries(body.adx).forEach(([type, rows]) => {
                rows.forEach((row, index) => {
                    if (!row.id) errors[`adx.${type}.${index}.id`] = 'Enter an ad unit ID or remove the row';
                    else if (!NO_SPACE_RE.test(row.id)) errors[`adx.${type}.${index}.id`] = 'Ad unit ID cannot contain spaces';
                    if (!/^\d+$/.test(row.weight)) {
                        errors[`adx.${type}.${index}.weight`] = row.weight.startsWith('-') ? 'Weight cannot be negative' : 'Weight must be a whole number';
                    }
                });
            });
            return errors;
        }

        async function load() {
            setSectionLoading(form, true);
            try {
                const { data } = await api('ads/get_config.php');
                render(data);
            } catch (err) {
                toast(err.message, 'error');
            } finally {
                setSectionLoading(form, false);
            }
        }

        renderPalette();
        bindSubmit(form, {
            validate,
            async save() {
                const json = await api('ads/save_config.php', { method: 'POST', body: gather() });
                render(json.data);
                toast('Ads configuration saved');
            },
        });
        load();
    };

    pages.users = function () {
        const state = { page: 1, source: '', search: '', pages: 1 };
        let searchTimer = null;

        async function load() {
            const params = new URLSearchParams({ page: state.page, source: state.source, search: state.search });
            const tbody = $('#userRows');
            tbody.innerHTML = '<tr><td colspan="5" class="table-empty"><span class="spinner"></span></td></tr>';
            try {
                const { data } = await api(`users/user_stats.php?${params}`);
                ['organic', 'marketing', 'total'].forEach((key) => {
                    $(`[data-stat="${key}"]`).textContent = formatNumber(data.summary[key]);
                });
                state.pages = data.pages;
                tbody.innerHTML = data.users.length ? data.users.map((u) => `
                    <tr>
                        <td data-label="Device ID"><span class="mono">${esc(u.device_id)}</span></td>
                        <td data-label="Source"><span class="badge badge-${esc(u.source)}">${esc(u.source)}</span></td>
                        <td data-label="App version">${esc(u.app_version || '–')}</td>
                        <td data-label="Installed">${esc(formatDate(u.created_at))}</td>
                        <td data-label="Last seen">${esc(formatDate(u.last_seen_at))}</td>
                    </tr>`).join('') : '<tr><td colspan="5" class="table-empty">No users found</td></tr>';
                $('#pageInfo').textContent = `Page ${data.page} of ${data.pages} · ${formatNumber(data.total)} users`;
                $('#prevPage').disabled = data.page <= 1;
                $('#nextPage').disabled = data.page >= data.pages;
            } catch (err) {
                tbody.innerHTML = '<tr><td colspan="5" class="table-empty">Could not load users</td></tr>';
                toast(err.message, 'error');
            }
        }

        $('#userSource').addEventListener('change', (e) => {
            state.source = e.target.value;
            state.page = 1;
            load();
        });
        $('#userSearch').addEventListener('input', (e) => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                state.search = e.target.value.trim();
                state.page = 1;
                load();
            }, 300);
        });
        $('#prevPage').addEventListener('click', () => { if (state.page > 1) { state.page--; load(); } });
        $('#nextPage').addEventListener('click', () => { if (state.page < state.pages) { state.page++; load(); } });
        load();
    };

    pages.facebook = function () {
        const form = $('#facebookForm');

        function apply(data) {
            fillForm(form, {
                facebook_app_id: data.facebook_app_id,
                facebook_client_token: data.facebook_client_token,
                facebook_secret_key: '',
                clear_secret: false,
            });
            $('#secretHint').textContent = data.facebook_secret_set
                ? 'A secret key is saved. Leave empty to keep it.'
                : 'No secret key saved yet.';
        }

        async function load() {
            setSectionLoading(form, true);
            try {
                const { data } = await api('marketing/facebook_config.php');
                apply(data);
            } catch (err) {
                toast(err.message, 'error');
            } finally {
                setSectionLoading(form, false);
            }
        }

        bindSubmit(form, {
            validate() {
                const d = readForm(form);
                const errors = {};
                if (d.facebook_app_id && !/^\d{5,30}$/.test(d.facebook_app_id)) errors.facebook_app_id = 'Facebook App ID contains digits only';
                if (d.facebook_client_token && !/^[A-Za-z0-9]{8,100}$/.test(d.facebook_client_token)) errors.facebook_client_token = 'Client token contains letters and digits only';
                if (d.facebook_secret_key && !/^\S{8,255}$/.test(d.facebook_secret_key)) errors.facebook_secret_key = 'Secret key cannot contain spaces';
                return errors;
            },
            async save() {
                const json = await api('marketing/facebook_config.php', { method: 'POST', body: readForm(form) });
                apply(json.data);
                toast('Facebook settings saved');
            },
        });
        load();
    };

    document.addEventListener('DOMContentLoaded', () => {
        initChrome();
        const page = pages[document.body.dataset.page];
        if (page) page();
    });
})();
