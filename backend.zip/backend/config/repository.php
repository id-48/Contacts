<?php
declare(strict_types=1);

require_once __DIR__ . '/database.php';

const BOOL_SETTING_KEYS = [
    'force_update',
    'splash_after_fullscreen_ad',
    'custom_ads_enabled',
    'app_open_on_resume',
    'launcher_enabled',
    'welcome_enabled',
    'theme_selection_enabled',
    'language_selection_enabled',
    'after_call_organic_enabled',
    'after_call_marketing_enabled',
];

const STRING_SETTING_KEYS = [
    'privacy_policy_url' => 500,
    'app_version' => 20,
    'app_link' => 500,
    'minimum_version' => 20,
    'force_update_message' => 500,
    'custom_ads_url' => 500,
    'facebook_app_id' => 100,
    'facebook_client_token' => 100,
];

const URL_SETTING_KEYS = ['privacy_policy_url', 'app_link', 'custom_ads_url'];

function get_settings(): array
{
    $row = db()->query('SELECT * FROM app_settings WHERE id = 1')->fetch();
    if (!$row) {
        db()->exec('INSERT IGNORE INTO app_settings (id) VALUES (1)');
        $row = db()->query('SELECT * FROM app_settings WHERE id = 1')->fetch();
    }
    foreach (BOOL_SETTING_KEYS as $key) {
        $row[$key] = (bool) $row[$key];
    }
    $row['config_version'] = (int) $row['config_version'];
    return $row;
}

/** Settings safe to show in the admin UI (the Facebook secret is replaced with a flag). */
function get_admin_settings(): array
{
    $settings = get_settings();
    $settings['facebook_secret_set'] = $settings['facebook_secret_key'] !== '';
    unset($settings['facebook_secret_key'], $settings['id']);
    return $settings;
}

function bump_config_version(): void
{
    db()->exec('UPDATE app_settings SET config_version = config_version + 1 WHERE id = 1');
}

function get_screen_configs(): array
{
    $rows = db()->query('SELECT * FROM screen_ad_config ORDER BY sort_order, id')->fetchAll();
    return array_map(static fn(array $r): array => [
        'screen_key' => $r['screen_key'],
        'label' => $r['label'] !== '' ? $r['label'] : $r['screen_key'],
        'native_big' => (bool) $r['native_big_enabled'],
        'native_small' => (bool) $r['native_small_enabled'],
        'banner' => (bool) $r['banner_enabled'],
        'fullscreen' => (bool) $r['fullscreen_enabled'],
        'is_default' => in_array($r['screen_key'], DEFAULT_SCREENS, true),
    ], $rows);
}

function get_ad_units(): array
{
    $units = ['admob' => [], 'tradplus' => []];
    foreach (ADMOB_TYPES as $type) {
        $units['admob'][$type] = ['enabled' => false, 'id' => ''];
    }
    foreach (TRADPLUS_TYPES as $type) {
        $units['tradplus'][$type] = ['enabled' => false, 'id' => ''];
    }
    $rows = db()->query("SELECT provider, ad_type, ad_unit_id, enabled FROM ad_units WHERE provider IN ('admob', 'tradplus')")->fetchAll();
    foreach ($rows as $r) {
        if (isset($units[$r['provider']][$r['ad_type']])) {
            $units[$r['provider']][$r['ad_type']] = [
                'enabled' => (bool) $r['enabled'],
                'id' => $r['ad_unit_id'],
            ];
        }
    }
    return $units;
}

function get_adx_ids(bool $onlyUsable = false): array
{
    $adx = array_fill_keys(ADX_TYPES, []);
    $rows = db()->query('SELECT ad_type, ad_unit_id, weight, enabled FROM adx_weighted_ids ORDER BY ad_type, sort_order, id')->fetchAll();
    foreach ($rows as $r) {
        if ($onlyUsable && (!(bool) $r['enabled'] || (int) $r['weight'] <= 0 || $r['ad_unit_id'] === '')) {
            continue;
        }
        $adx[$r['ad_type']][] = [
            'id' => $r['ad_unit_id'],
            'weight' => (int) $r['weight'],
        ];
    }
    return $adx;
}

function get_fullscreen_sequence(): array
{
    $rows = db()->query('SELECT ad_type FROM fullscreen_sequence WHERE enabled = 1 ORDER BY sort_order, id')->fetchAll();
    return array_column($rows, 'ad_type');
}

function get_ads_config(): array
{
    $settings = get_settings();
    $units = get_ad_units();
    return [
        'admob' => $units['admob'],
        'tradplus' => $units['tradplus'],
        'custom' => [
            'enabled' => $settings['custom_ads_enabled'],
            'url' => $settings['custom_ads_url'],
        ],
        'adx' => get_adx_ids(),
        'fullscreen_sequence' => get_fullscreen_sequence(),
        'screen_ads' => get_screen_configs(),
    ];
}

/** The public configuration returned to the Android app. Never contains secrets. */
function build_public_config(): array
{
    $s = get_settings();

    $screenAds = [];
    foreach (get_screen_configs() as $screen) {
        $screenAds[$screen['screen_key']] = [
            'native_big' => $screen['native_big'],
            'native_small' => $screen['native_small'],
            'banner' => $screen['banner'],
            'fullscreen' => $screen['fullscreen'],
        ];
    }

    $units = get_ad_units();
    $customEnabled = $s['custom_ads_enabled'] && $s['custom_ads_url'] !== '';

    return [
        'config_version' => $s['config_version'],
        'app' => [
            'app_version' => $s['app_version'],
            'app_link' => $s['app_link'],
            'privacy_policy' => $s['privacy_policy_url'],
        ],
        'force_update' => [
            'enabled' => $s['force_update'],
            'minimum_version' => $s['minimum_version'],
            'message' => $s['force_update_message'],
            'app_link' => $s['app_link'],
        ],
        'screens' => [
            'welcome' => $s['welcome_enabled'],
            'theme_selection' => $s['theme_selection_enabled'],
            'language_selection' => $s['language_selection_enabled'],
            'after_call_organic' => $s['after_call_organic_enabled'],
            'after_call_marketing' => $s['after_call_marketing_enabled'],
        ],
        'features' => [
            'splash_after_fullscreen_ad' => $s['splash_after_fullscreen_ad'],
            'app_open_on_resume' => $s['app_open_on_resume'],
            'launcher_enabled' => $s['launcher_enabled'],
        ],
        'marketing' => [
            'facebook_app_id' => $s['facebook_app_id'],
            'facebook_client_token' => $s['facebook_client_token'],
        ],
        'ads' => [
            'screen_ads' => (object) $screenAds,
            'admob' => $units['admob'],
            'tradplus' => $units['tradplus'],
            'adx' => get_adx_ids(true),
            'custom' => [
                'enabled' => $customEnabled,
                'url' => $customEnabled ? $s['custom_ads_url'] : '',
            ],
            'fullscreen_sequence' => get_fullscreen_sequence(),
        ],
    ];
}
