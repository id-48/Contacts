<?php
declare(strict_types=1);

// 'production' hides PHP warnings/notices from every response.
define('APP_ENV', getenv('APP_ENV') ?: 'production');
define('APP_NAME', 'Contacts Admin');

const SCREEN_KEY_PATTERN = '/^[a-z][a-z0-9_]{1,49}$/';
const DEFAULT_SCREENS = [
    'welcome',
    'theme_selection',
    'language_selection',
    'after_call_organic',
    'after_call_marketing',
    'launcher',
];
const AD_PROVIDERS = ['admob', 'tradplus', 'adx', 'custom'];
const AD_TYPES = ['banner', 'interstitial', 'native', 'reward', 'app_open'];
const ADMOB_TYPES = ['banner', 'interstitial', 'native', 'reward', 'app_open'];
const TRADPLUS_TYPES = ['banner', 'interstitial', 'native', 'reward'];
const ADX_TYPES = ['banner', 'interstitial', 'native', 'app_open', 'reward'];
const FULLSCREEN_TYPES = ['interstitial', 'reward', 'app_open', 'custom'];
const USER_SOURCES = ['organic', 'marketing'];

error_reporting(E_ALL);
ini_set('display_errors', APP_ENV === 'production' ? '0' : '1');
ini_set('log_errors', '1');
date_default_timezone_set('UTC');

function json_response(bool $success, string $message, $data = null, int $status = 200): void
{
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
    }
    echo json_encode(
        ['success' => $success, 'message' => $message, 'data' => $data],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
    exit;
}

function validation_error(array $errors): void
{
    json_response(false, 'Please fix the highlighted fields', ['errors' => $errors], 422);
}

/** Turns any uncaught error inside an API script into a safe JSON 500. */
function api_bootstrap(): void
{
    set_exception_handler(static function (Throwable $e): void {
        error_log('[contacts-admin] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
        json_response(false, 'Something went wrong. Please try again.', null, 500);
    });
    set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
        throw new ErrorException($message, 0, $severity, $file, $line);
    });
}

function require_method(string $method): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $method) {
        header('Allow: ' . $method);
        json_response(false, 'Method not allowed', null, 405);
    }
}

function read_json_body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || trim($raw) === '') {
        return [];
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        json_response(false, 'Invalid JSON body', null, 400);
    }
    return $data;
}

function to_bool($value): bool
{
    if (is_bool($value)) {
        return $value;
    }
    if (is_int($value)) {
        return $value === 1;
    }
    return in_array(strtolower(trim((string) $value)), ['1', 'true', 'on', 'yes'], true);
}

function clean_string($value, int $maxLength = 255): string
{
    return mb_substr(trim((string) ($value ?? '')), 0, $maxLength);
}

function is_valid_url(string $url): bool
{
    if (filter_var($url, FILTER_VALIDATE_URL) === false) {
        return false;
    }
    $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
    return in_array($scheme, ['http', 'https', 'market'], true);
}

function is_valid_version(string $version): bool
{
    return (bool) preg_match('/^\d+(\.\d+){0,3}$/', $version);
}

function is_valid_ad_unit_id(string $id): bool
{
    return $id === '' || (bool) preg_match('/^\S{1,191}$/', $id);
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
