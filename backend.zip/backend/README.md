# Contacts Admin Panel and Remote Config API

Core PHP 8 + MySQL admin panel that controls the Android app's screens, ads, force update,
launcher mode and Facebook marketing. The Android app reads one public endpoint
(`api/app/config.php`) and caches the result, so the app keeps working when the server is down.

```text
backend/
├── admin/          Admin pages (login, dashboard, settings, ads, users, Facebook)
├── api/            JSON endpoints (admin endpoints need a session + CSRF token)
├── assets/         admin.css / admin.js (no build step)
├── config/         config.php, database.php, auth.php, repository.php (not web-accessible)
├── sql/            contacts_admin.sql (schema + seed data)
└── setup_admin.php One-time admin account creation
```

## 1. Database import

1. Create the database and import the schema and seed rows:

   ```bash
   mysql -u root -p -e "CREATE DATABASE contacts_admin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
   mysql -u root -p contacts_admin < sql/contacts_admin.sql
   ```

2. The seed creates the single `app_settings` row, empty ad units, the default fullscreen sequence
   and the six default screens (`welcome`, `theme_selection`, `language_selection`,
   `after_call_organic`, `after_call_marketing`, `launcher`) with every ad switch off.

## 2. PHP configuration

- PHP 8.0+ with `pdo_mysql` and `json`. Apache with `mod_rewrite`/`.htaccess` support, or the
  equivalent deny rules on Nginx for `config/`, `sql/`, `admin/includes/` and `*.md`.
- Database credentials come from environment variables, with local defaults in
  `config/database.php`:

  | Variable  | Default          |
  |-----------|------------------|
  | `DB_HOST` | `127.0.0.1`      |
  | `DB_PORT` | `3306`           |
  | `DB_NAME` | `contacts_admin` |
  | `DB_USER` | `root`           |
  | `DB_PASS` | *(empty)*        |
  | `APP_ENV` | `production`     |

- In `production` PHP errors are hidden and APIs return a generic message; set `APP_ENV=development`
  locally to see them.
- Serve the panel over HTTPS. Session cookies are `HttpOnly` and `SameSite=Lax`, and become `Secure`
  automatically on HTTPS.

## 3. Admin login

1. After importing the database run, once:

   ```bash
   php setup_admin.php
   ```

   It creates `admin@gmail.com` with the initial password defined in `setup_admin.php`, stored with
   `password_hash()`. The script refuses to run if an admin already exists.
2. **Delete `setup_admin.php` from the server** after it has run.
3. Login uses `password_verify()`. Five failed attempts lock login for five minutes per session.

## 4. API base URL

All endpoints live under the folder you deploy `backend/` to, for example
`https://your-domain.com/backend/`. Responses always use:

```json
{ "success": true, "message": "OK", "data": {} }
```

Validation errors return HTTP 422 with `data.errors` keyed by field.

| Endpoint | Method | Auth | Purpose |
|---|---|---|---|
| `api/app/config.php` | GET | public | Full remote config for Android |
| `api/users/register_or_update.php` | POST | public | Android user registration (`device_id`, `source`, `app_version`) |
| `api/auth/login.php` | POST | CSRF | Admin login |
| `api/dashboard/stats.php` | GET | admin | User counts |
| `api/app/get_settings.php`, `save_settings.php` | GET / POST | admin | App settings |
| `api/ads/get_config.php`, `save_config.php` | GET / POST | admin | Ads configuration |
| `api/users/user_stats.php` | GET | admin | Paginated user list |
| `api/marketing/facebook_config.php` | GET / POST | admin | Facebook App ID / token / secret |

Admin POST endpoints require the `X-CSRF-Token` header (the panel's JS sends it automatically).
Every save increments `config_version`; Android ignores responses whose version it already has.
The Facebook App Secret is write-only: it is never returned by any endpoint, including to Android.

## 5. Opening the admin panel

Open `https://your-domain.com/backend/admin/` (the backend root redirects there) and sign in.
Menu: Dashboard, App Settings, Ads Configuration, Users, Facebook Marketing.

## 6. Configuring ads

On **Ads Configuration**:

1. **AdMob** and **TradPlus**: enter a unit ID per format and turn it on. A format that is off or
   empty is skipped.
2. **ADX (Google Ad Manager)**: add one or more IDs per format, each with a weight. Each request
   picks one ID with probability `weight / total weight`; weight `0` or a disabled row is never
   used.
3. **Custom ads**: turn on and enter the URL of a JSON file (format below).
4. **Fullscreen sequence**: the order of fullscreen ads (`interstitial`, `reward`, `app_open`,
   `custom`). Each fullscreen trigger shows the next item; the position is remembered on the device
   and wraps around.
5. **Per-screen ads**: for each screen choose Native Big, Native Small, Banner and Fullscreen.

On the device, providers are tried in this order until one fills: **AdMob → TradPlus → ADX →
Custom**. While a banner or native loads, a matching shimmer is shown; on no-fill the slot is hidden.
Fullscreen ads show an "Ads Loading..." card and give up after about 9 seconds, so the user is never
blocked.

App Settings also controls: Splash Screen After Full Screen Ad, App Open Ad On Resume, Launcher
Mode, force update (minimum version + message), and the onboarding/after-call screen switches.

### Custom ads JSON format

The custom URL must return a JSON object. Every key is optional; a format without a valid creative
falls through to "no fill". `click_url`, `image` and `icon` must be `https://`, `http://` or
`market://` links.

```json
{
  "banner":       { "image": "https://cdn.example.com/banner-320x50.png", "click_url": "https://example.com" },
  "native":       { "title": "Try our app", "body": "Short description", "icon": "https://cdn.example.com/icon.png",
                    "image": "https://cdn.example.com/cover.jpg", "cta": "Install", "click_url": "market://details?id=com.example" },
  "interstitial": { "image": "https://cdn.example.com/full.jpg", "title": "Optional title", "cta": "Open", "click_url": "https://example.com" },
  "reward":       { "image": "...", "click_url": "..." },
  "app_open":     { "image": "...", "click_url": "..." }
}
```

`reward` and `app_open` fall back to `interstitial` when missing. Native needs at least `title` and
`click_url`; banner and fullscreen need `image` and `click_url`.

## 7. Android API integration

- Set the API base URL at build time (it must end with `/`):

  ```properties
  # ~/.gradle/gradle.properties or the project's gradle.properties
  contactsApiBaseUrl=https://your-domain.com/backend/
  admobAppId=ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY
  ```

  Without `contactsApiBaseUrl` the app skips network calls and runs on cached/default config.
  Without `admobAppId` the Google sample App ID is used, which only serves test ads.
- `RemoteConfigManager` loads the cached config instantly, refreshes in the background (at most every
  30 minutes) and merges valid sections only, so a broken section never replaces a good cache.
- `UserSourceManager` classifies the install once via the Play Install Referrer (`organic` or
  `marketing`) and registers the device; an organic user can later become marketing, never the
  reverse.
- Ads are shown only through `AdsManager` (`showBanner`, `showNativeBig`, `showNativeSmall`,
  `showFullscreen`). Today they are integrated only into `WelcomeActivity`.
- Debug builds log the flow under the tags `AdsConfig`, `AdsManager`, `AdsFallback`, `AdsInline`,
  `AdsFullscreen`, `AdsAppOpen`, `AdsGuard`, `AdsTradPlus` and `AdsAdx`. Release builds log nothing.

### Android dependency changes

Added in `gradle/libs.versions.toml` / `app/build.gradle`:

| Library | Why |
|---|---|
| `com.google.android.gms:play-services-ads` 23.6.0 | AdMob and Ad Manager (ADX) |
| `com.tradplusad:tradplus` 16.8.40.1, `tradplus-googlex`, `tradplus-facebook`, `com.facebook.android:audience-network-sdk` 6.22.0 | TradPlus mediation and its Google / Meta adapters |
| `com.android.installreferrer:installreferrer` 2.2 | Organic vs marketing detection |
| `com.facebook.android:facebook-core` 18.0.3 | Facebook marketing (initialized from the admin's App ID / Client Token; auto-init is off in the manifest) |
| `androidx.lifecycle:lifecycle-process` | App-open-on-resume detection |
| `org.json:json` (tests only) | JSON parsing in JVM unit tests |

The manifest also gained the `AD_ID` and `REQUEST_DELETE_PACKAGES` permissions (the latter for
uninstalling apps from Launcher Mode), the AdMob App ID and the TradPlus App ID meta-data.

## 8. Adding a new screen

1. In the admin panel's **Ads Configuration → Per-screen ads**, add a screen key (lowercase letters,
   digits and `_`, e.g. `settings_home`). It is saved to `screen_ad_config`; default screens cannot
   be removed. To make it a default for fresh installs, also add it to `DEFAULT_SCREENS` in
   `config/config.php` and to the seed in `sql/contacts_admin.sql`.
2. In the Android screen, add `FrameLayout` containers (`visibility="gone"`) and call:

   ```java
   AdsManager.showNativeBig(this, binding.nativeBigContainer, "settings_home");
   AdsManager.showBanner(this, binding.bannerContainer, "settings_home");
   AdsManager.showFullscreen(this, "settings_home", this::goNext);
   ```

   Unknown or disabled screen keys simply show nothing and `showFullscreen` continues at once.
3. If the screen itself should be switchable (like Welcome), add a boolean column to
   `app_settings`, expose it under `screens` in `build_public_config()`, add it to App Settings, and
   check `RemoteConfigManager.get().isScreenEnabled("key")` on Android.

## 9. Adding a new ad provider

1. Backend: add the key to `AD_PROVIDERS` (and a `*_TYPES` list) in `config/config.php`, store its
   IDs in `ad_units`, expose them in `build_public_config()` under `ads`, and add the inputs to
   `admin/ads-config.php` / `assets/js/admin.js`. Validate IDs in `api/ads/save_config.php`.
2. Android: add a value to `AdProviderType`, parse its IDs in `AdsConfig.fromJson`, implement
   `ads/providers/AdProvider` (banner, native, fullscreen; call the callback exactly once and return
   ads that can be destroyed), then insert it into `AdsManager.PROVIDERS` at the desired fallback
   position.

## 10. Adding a new fullscreen sequence type

1. Backend: add the key to `FULLSCREEN_TYPES` in `config/config.php` (and to the `fullscreen_sequence`
   ENUM in the SQL if you keep the ENUM) and to the sequence chip choices in `assets/js/admin.js`.
2. Android: add a value to `FullscreenType` with its key and the `AdType` to request (or `null` for a
   custom-only type, then route it in `FullscreenAdManager.show`). Unknown keys from the server are
   ignored, so older app versions keep working.
